import React from 'react'

const Footer = () => {
  return (
    <>
      <footer className='p-5 text-center'>@2024 swiftcall .All right reserved</footer>
    </>
  );
}

export default Footer